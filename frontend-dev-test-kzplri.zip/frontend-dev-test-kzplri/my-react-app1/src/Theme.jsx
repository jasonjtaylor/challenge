export const lightTheme = {
	body: "#fdf8e7",
	text: "#363537",
	toggleBorder: "#FFF",
	background: "#363537",
};
export const darkTheme = {
	body: "#363537",
	text: "#FFF",
	color: "#FFF",
	toggleBorder: "#fff",
	background: "#999",
};
